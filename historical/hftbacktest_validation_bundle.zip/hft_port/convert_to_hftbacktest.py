from __future__ import annotations
import argparse
from pathlib import Path
import numpy as np

# HftBacktest v2 constants from official docs.
DEPTH_EVENT=1
TRADE_EVENT=2
DEPTH_CLEAR_EVENT=3
DEPTH_SNAPSHOT_EVENT=4
EXCH_EVENT=1<<31
LOCAL_EVENT=1<<30
BUY_EVENT=1<<29
SELL_EVENT=1<<28
EVENT_DTYPE=np.dtype([
    ('ev','<u8'),('exch_ts','<i8'),('local_ts','<i8'),('px','<f8'),('qty','<f8'),
    ('order_id','<u8'),('ival','<i8'),('fval','<f8')
], align=True)


def _row(ev, ts, px, qty, ival=0):
    return (np.uint64(ev|EXCH_EVENT|LOCAL_EVENT), int(ts), int(ts), float(px), float(qty), 0, int(ival), 0.0)


def convert_nse(src: Path, dst: Path):
    z=np.load(src)
    bids=np.asarray(z['bids'],float); asks=np.asarray(z['asks'],float)
    ts=np.asarray(z['ts'],np.int64)*1_000_000
    tr_price=np.asarray(z['tr_price'],float); tr_qty=np.asarray(z['tr_qty'],float)
    tr_side=np.asarray(z['tr_side'],np.int64); tr_bookidx=np.asarray(z['tr_bookidx'],np.int64)
    # Stable source order. Trade timestamps are not present in the source; we keep the
    # snapshot timestamp and source order instead of inventing sub-snapshot times.
    by_book=[[] for _ in range(len(ts))]
    for k,bi in enumerate(tr_bookidx): by_book[int(bi)].append(k)
    rows=[]
    for i,t in enumerate(ts):
        b=bids[i]; a=asks[i]
        # Official HftBacktest snapshot conversion pattern: clear within snapshot range,
        # then publish snapshot levels.
        rows.append(_row(DEPTH_CLEAR_EVENT|BUY_EVENT,t,b[-1,0],0,i))
        for px,q in b: rows.append(_row(DEPTH_SNAPSHOT_EVENT|BUY_EVENT,t,px,q,i))
        rows.append(_row(DEPTH_CLEAR_EVENT|SELL_EVENT,t,a[-1,0],0,i))
        for px,q in a: rows.append(_row(DEPTH_SNAPSHOT_EVENT|SELL_EVENT,t,px,q,i))
        for k in by_book[i]:
            sideflag=BUY_EVENT if tr_side[k]>0 else SELL_EVENT
            rows.append(_row(TRADE_EVENT|sideflag,t,tr_price[k],tr_qty[k],i))
    data=np.array(rows,dtype=EVENT_DTYPE)
    dst.parent.mkdir(parents=True,exist_ok=True)
    np.savez_compressed(dst,data=data)
    return data


def convert_goog(src: Path, dst: Path):
    z=np.load(src)
    bb=np.asarray(z['bb'],float); ba=np.asarray(z['ba'],float)
    bq=np.asarray(z['bq'],float); aq=np.asarray(z['aq'],float)
    ts=np.asarray(z['ts'],np.int64)*1_000_000
    rows=[]
    for i,t in enumerate(ts):
        # L1 only: clear and republish each side. No TRADE_EVENT is fabricated.
        rows.append(_row(DEPTH_CLEAR_EVENT|BUY_EVENT,t,bb[i],0,i))
        rows.append(_row(DEPTH_SNAPSHOT_EVENT|BUY_EVENT,t,bb[i],bq[i],i))
        rows.append(_row(DEPTH_CLEAR_EVENT|SELL_EVENT,t,ba[i],0,i))
        rows.append(_row(DEPTH_SNAPSHOT_EVENT|SELL_EVENT,t,ba[i],aq[i],i))
    data=np.array(rows,dtype=EVENT_DTYPE)
    dst.parent.mkdir(parents=True,exist_ok=True)
    np.savez_compressed(dst,data=data)
    return data


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('kind',choices=['nse','goog']); ap.add_argument('src',type=Path); ap.add_argument('dst',type=Path)
    a=ap.parse_args()
    data=convert_nse(a.src,a.dst) if a.kind=='nse' else convert_goog(a.src,a.dst)
    print(f'wrote {len(data):,} events to {a.dst}')

if __name__=='__main__': main()
