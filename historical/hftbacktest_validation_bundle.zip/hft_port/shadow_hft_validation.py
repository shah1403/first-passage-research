"""Independent validation on HftBacktest-formatted feeds.

This does NOT import the user's audited engine. It rebuilds snapshots/trade counts from
HftBacktest v2 events, recomputes the signal/history causally, and uses HftBacktest-like
5ms aggressive market-order fills at the first reconstructed book at/after arrival.
It exists because the sandbox cannot download the compiled hftbacktest wheel.
"""
from __future__ import annotations
import argparse, heapq, json
from dataclasses import dataclass
from pathlib import Path
import numpy as np
import pandas as pd

DEPTH_EVENT=1; TRADE_EVENT=2; DEPTH_CLEAR_EVENT=3; DEPTH_SNAPSHOT_EVENT=4
EXCH_EVENT=1<<31; LOCAL_EVENT=1<<30; BUY_EVENT=1<<29; SELL_EVENT=1<<28
EPS=1e-9

@dataclass
class BookTape:
    ts: np.ndarray; bids: np.ndarray; asks: np.ndarray; trade_count: np.ndarray


def rebuild_nse(hbt_npz: Path) -> BookTape:
    d=np.load(hbt_npz)['data']
    # source snapshot id is carried in ival; build last full snapshot for each id.
    ids=np.unique(d['ival'])
    ts=[]; bids=[]; asks=[]; counts=[]; trade_n=0
    for sid in ids:
        g=d[d['ival']==sid]
        if len(g)==0: continue
        b=g[((g['ev'] & BUY_EVENT)!=0) & ((g['ev'] & 0xff)==DEPTH_SNAPSHOT_EVENT)]
        a=g[((g['ev'] & SELL_EVENT)!=0) & ((g['ev'] & 0xff)==DEPTH_SNAPSHOT_EVENT)]
        tr=g[((g['ev'] & 0xff)==TRADE_EVENT)]
        if len(b)==0 or len(a)==0: continue
        # Preserve source level order exactly. Sorting here would silently repair
        # malformed snapshots that the audited strategy correctly censors.
        b=np.stack([b['px'],b['qty']],axis=1); a=np.stack([a['px'],a['qty']],axis=1)
        ts.append(int(g['local_ts'][0])); bids.append(b); asks.append(a)
        trade_n += len(tr); counts.append(trade_n)
    L=max(max(map(len,bids)),max(map(len,asks)))
    def pad(xs,side):
        out=np.zeros((len(xs),L,2),float)
        for i,x in enumerate(xs): out[i,:len(x)]=x
        return out
    return BookTape(np.array(ts,np.int64),pad(bids,1),pad(asks,-1),np.array(counts,np.int64))


def valid_row(t,i):
    b=t.bids[i]; a=t.asks[i]
    if not np.isfinite(b).all() or not np.isfinite(a).all(): return False
    if np.any(b[:,1] < 0) or np.any(a[:,1] < 0): return False
    if b[0,1] <= 0 or a[0,1] <= 0: return False
    bp=b[b[:,1]>0,0]; ap=a[a[:,1]>0,0]
    if len(bp)==0 or len(ap)==0 or np.any(bp<=0) or np.any(ap<=0): return False
    if np.any(np.diff(bp)>=0) or np.any(np.diff(ap)<=0) or bp[0]>=ap[0]: return False
    return True

def arrival(t,i,lat=5_000_000):
    j=max(i,int(np.searchsorted(t.ts,int(t.ts[i])+lat)))
    return j if j<len(t.ts) else None

def deadline(t,i,n=50):
    j=int(np.searchsorted(t.trade_count,int(t.trade_count[i])+n))
    return j if j<len(t.ts) else None

def best_fill(t,i,side,entry,q=1):
    if i is None or not valid_row(t,i): return None
    book=t.asks[i] if ((side==1)==entry) else t.bids[i]
    book=book[book[:,1]>0]
    rem=float(q); cost=0.; done=0.
    for px,qty in book:
        take=min(rem,qty)
        if take>0: cost+=take*px; done+=take; rem-=take
        if rem<=EPS: return cost/done
    return None

def fee_leg(q,p,buy):
    turnover=q*p
    brokerage=min(20.,turnover*.0003)
    exchange=turnover*.0000307; sebi=turnover*.000001; ipft=turnover*.000000001
    gst=.18*(brokerage+exchange+sebi+ipft)
    tax=turnover*(.00003 if buy else .00025)
    return brokerage+exchange+sebi+ipft+gst+tax

def pnl(side,entry,out,q=1):
    gross=q*side*(out-entry)
    fees=fee_leg(q,entry,side==1)+fee_leg(q,out,side!=1)
    return gross,fees,gross-fees

def features(t):
    valid=np.array([valid_row(t,i) for i in range(len(t.ts))])
    bq=t.bids[:,0,1]; aq=t.asks[:,0,1]
    with np.errstate(divide='ignore',invalid='ignore'):
        imb=(bq-aq)/(bq+aq)
    ss=pd.Series(np.where(valid,imb,np.nan))
    bucket=np.searchsorted([-0.8,-0.4,0.4,0.8],ss.to_numpy(),side='right')
    spread=pd.Series(np.where(valid,t.asks[:,0,0]-t.bids[:,0,0],np.nan))
    tight=spread.le(spread.expanding(min_periods=20).quantile(.25)).to_numpy()
    eligible=valid & (ss.abs().to_numpy()>=.8) & tight
    return bucket,eligible

def label(t,i):
    ei=arrival(t,i); end=deadline(t,i)
    if ei is None or (end is not None and ei>=end): return None,None
    ents={s:best_fill(t,ei,s,True) for s in (-1,1)}
    if any(v is None for v in ents.values()): return None,None
    stop=end if end is not None else len(t.ts)-1
    for j in range(ei+1,stop+1):
        if not valid_row(t,j): return None,None
        hits=[]
        for s in (-1,1):
            out=best_fill(t,j,s,False)
            if out is not None and pnl(s,ents[s],out)[2]>EPS: hits.append(s)
        if len(hits)>1: return None,j
        if hits: return hits[0],j
    if end is None: return None,None
    return 0,end

class Hist:
    def __init__(self): self.c={}; self.state=None; self.latest=-1; self.total=0; self.ps=[]; self.pc=[]; self.origin=0
    def advance(self,now):
        while self.ps and self.ps[0][0]<now:
            _,o,y,b,s=heapq.heappop(self.ps)
            if o>self.latest: self.state=y; self.latest=o
        while self.pc and self.pc[0][0]<now:
            _,o,y,b,s=heapq.heappop(self.pc)
            for k in [('all',),(b,),(b,s)]:
                self.c.setdefault(k,np.zeros(3))[y+1]+=1
            self.total+=1
    def probs(self,b,mode):
        k=(b,) if mode=='imbalance' else (b,self.state)
        x=self.c.get(k,np.zeros(3)); return (x+.5)/(x.sum()+1.5),int(x.sum())
    def schedule(self,t,i,b,y,ri):
        o=self.origin; self.origin+=1
        if y is None: return
        heapq.heappush(self.ps,(int(t.ts[ri]),o,int(y),int(b),self.state))
        di=deadline(t,i)
        if di is not None: heapq.heappush(self.pc,(int(t.ts[di]),o,int(y),int(b),self.state))

def execute(t,i,side):
    ei=arrival(t,i); end=deadline(t,i)
    if ei is None or (end is not None and ei>=end): return None
    ent=best_fill(t,ei,side,True)
    if ent is None: return None
    stop=end if end is not None else len(t.ts)-1
    trigger=None; reason=None
    for j in range(ei+1,stop+1):
        out=best_fill(t,j,side,False)
        if out is not None and pnl(side,ent,out)[2]>EPS:
            trigger=j; reason='profit_opportunity'; break
        if j==end:
            trigger=j; reason='50_trade_timeout'; break
    if trigger is None: return {'status':'open_unresolved','entry_i':ei}
    xi=arrival(t,trigger)
    if xi is None: return {'status':'open_unresolved','entry_i':ei}
    out=best_fill(t,xi,side,False)
    if out is None: return {'status':'open_unresolved','entry_i':ei}
    g,f,n=pnl(side,ent,out)
    return {'status':'closed','entry_i':ei,'exit_i':xi,'gross':g,'fees':f,'net':n,'reason':reason,
            'wait_trades':int(t.trade_count[xi]-t.trade_count[i])}

def run(t,mode):
    bucket,elig=features(t); anchors=np.flatnonzero(elig & (np.arange(len(t.ts))%5==0))
    h=Hist(); blocked_i=-1; blocked_ts=-1; trades=[]; labels=[]
    for i in anchors:
        h.advance(int(t.ts[i])); p,n=h.probs(int(bucket[i]),mode); pm,p0,pp=p
        side=1 if pp>pm else -1 if pm>pp else 0
        y,ri=label(t,int(i)); labels.append(y); h.schedule(t,int(i),int(bucket[i]),y,ri)
        if h.total<30 or side==0 or i<=blocked_i or int(t.ts[i])<=blocked_ts: continue
        tr=execute(t,int(i),side)
        if tr is None: continue
        tr.update(anchor_i=int(i),side=side,pminus=float(pm),pzero=float(p0),pplus=float(pp))
        trades.append(tr)
        if tr['status']=='closed': blocked_i=tr['exit_i']; blocked_ts=int(t.ts[blocked_i])
        else: break
    closed=[x for x in trades if x['status']=='closed']
    return {
      'mode':mode,'anchors':len(anchors),'labels_censored':sum(y is None for y in labels),
      'closed_trades':len(closed),'unresolved':sum(x['status']!='closed' for x in trades),
      'gross':sum(x['gross'] for x in closed),'fees':sum(x['fees'] for x in closed),'net':sum(x['net'] for x in closed),
      'timeouts':sum(x.get('reason')=='50_trade_timeout' for x in closed),
      'profit_triggers':sum(x.get('reason')=='profit_opportunity' for x in closed),
      'trades':closed
    }

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('feed',type=Path); ap.add_argument('--out',type=Path)
    a=ap.parse_args(); t=rebuild_nse(a.feed)
    res={m:run(t,m) for m in ['imbalance','imbalance_state']}
    printable={m:{k:v for k,v in r.items() if k!='trades'} for m,r in res.items()}
    print(json.dumps(printable,indent=2))
    if a.out: a.out.write_text(json.dumps(res,indent=2))
if __name__=='__main__': main()
