# HftBacktest-format port and independent validation

This bundle ports the NSE inputs to HftBacktest v2 event format and independently replays the locked strategy without importing the audited engine.

## Result

- TATAMOTORS, imbalance: 7 closed trades, gross 5.45, fees 7.653739713847, net -2.203739713847182.
- TATAMOTORS, imbalance+state: identical.
- INFY, both modes: 0 trades, 23 censored labels.
- The independent replay matches the audited engine exactly on summary metrics and on common trade-level fields (anchor, side, entry/exit indices, gross, fees, net, wait trades).
- Conversion integrity checks confirm timestamps, bids, asks, and cumulative trade counts reconstruct exactly from the HftBacktest-formatted feed.

## Files

- `convert_to_hftbacktest.py`: converts NSE L5 snapshots + linked trades into HftBacktest v2 structured events using clear-then-snapshot events and source trade events. No missing intra-snapshot trade timestamps are fabricated.
- `shadow_hft_validation.py`: independent HftBacktest-format replay of the locked 50-trade / 5 ms strategy.
- `verify_port.py`: verifies source -> HftBacktest-format round trip and compares the independent results to the audited engine.
- `validation_report.json`: exact verification report.
- `comparison.csv`: compact result comparison.
- `run_real_hftbacktest.py`: minimal compiled-HftBacktest loader/execution harness.

## Important limitation

The analysis sandbox cannot install or download the compiled `hftbacktest` wheel (outbound binary/PyPI access is blocked), so the actual compiled HftBacktest engine was not executed here. The independent validator consumes the official HftBacktest event representation and is deliberately separate from the audited engine.

The GOOG source has no trade prints, so an honest 50-trade HftBacktest replay cannot be constructed from it without inventing trades. It remains a book-update proxy experiment only.
