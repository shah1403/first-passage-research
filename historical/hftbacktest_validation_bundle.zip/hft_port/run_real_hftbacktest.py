"""Execution-only HftBacktest harness for converted feeds.

The signal schedule should be supplied as an NPZ/CSV generated causally outside the engine.
This file intentionally fails clearly if hftbacktest is not installed.
"""
import argparse
from pathlib import Path
import numpy as np

def main():
    try:
        from hftbacktest import BacktestAsset, HashMapMarketDepthBacktest
    except Exception as e:
        raise SystemExit('hftbacktest is not installed in this runtime: '+repr(e))
    ap=argparse.ArgumentParser(); ap.add_argument('feed',type=Path); a=ap.parse_args()
    data=np.load(a.feed)['data']
    # Exact asset configuration used for our execution validation.
    asset=(BacktestAsset().data([data]).linear_asset(1.0)
           .constant_order_latency(5_000_000,0)
           .risk_adverse_queue_model().no_partial_fill_exchange()
           .trading_value_fee_model(0.0,0.0).tick_size(0.05).lot_size(1.0))
    hbt=HashMapMarketDepthBacktest([asset])
    print('HftBacktest loaded feed; current timestamp:',hbt.current_timestamp)
    hbt.close()
if __name__=='__main__': main()
