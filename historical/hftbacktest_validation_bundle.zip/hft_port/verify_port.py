from pathlib import Path
import json, importlib.util, numpy as np

HERE=Path(__file__).parent
# Load the independent shadow module only.
spec=importlib.util.spec_from_file_location('shadow', HERE/'shadow_hft_validation.py')
shadow=importlib.util.module_from_spec(spec); spec.loader.exec_module(shadow)

DATASETS={
 'tatamotors': (Path('/mnt/data/market_raw/orderbook_tatamotors_10000snaps.npz'), HERE/'tatamotors_hbt.npz'),
 'infy': (Path('/mnt/data/market_raw/orderbook_infy_10000snaps.npz'), HERE/'infy_hbt.npz'),
}
report={}
for name,(src,feed) in DATASETS.items():
    z=np.load(src); t=shadow.rebuild_nse(feed)
    counts=np.cumsum(np.bincount(z['tr_bookidx'], minlength=len(z['ts'])))
    raw_ts=z['ts'].astype(np.int64)*1_000_000
    raw_b=np.asarray(z['bids'],float); raw_a=np.asarray(z['asks'],float)
    integrity={
      'timestamps_exact': bool(np.array_equal(raw_ts,t.ts)),
      'bids_exact_equal_nan': bool(np.array_equal(raw_b,t.bids,equal_nan=True)),
      'asks_exact_equal_nan': bool(np.array_equal(raw_a,t.asks,equal_nan=True)),
      'trade_counts_exact': bool(np.array_equal(counts,t.trade_count)),
      'source_snapshots': int(len(raw_ts)),
      'hbt_events': int(len(np.load(feed)['data'])),
    }
    audited=json.load(open(HERE/f'{name}_audited.json'))
    sh=json.load(open(HERE/f'{name}_shadow.json'))
    modes={}
    for mode in ['imbalance','imbalance_state']:
      ar=[x for x in audited['results'] if x['config']['mode']==mode][0]
      sr=sh[mode]
      summ=ar['summary']
      summary_fields={
        'closed_trades': (summ['closed_trades'],sr['closed_trades']),
        'labels_censored': (summ['labels_censored'],sr['labels_censored']),
        'gross': (summ['gross_closed'],sr['gross']),
        'fees': (summ['fees_closed'],sr['fees']),
        'net': (summ['net_closed'],sr['net']),
      }
      summary_match=all(abs(a-b)<1e-12 if isinstance(a,(int,float)) and isinstance(b,(int,float)) else a==b for a,b in summary_fields.values())
      trade_fields=['anchor_i','side','entry_i','exit_i','gross','fees','net','wait_trades']
      trade_match=len(ar['trades'])==len(sr['trades'])
      if trade_match:
        for x,y in zip(ar['trades'],sr['trades']):
          for f in trade_fields:
            if f not in x or f not in y:
              trade_match=False; break
            xv,yv=x[f],y[f]
            if isinstance(xv,(int,float)) and isinstance(yv,(int,float)):
              if abs(xv-yv)>1e-12: trade_match=False; break
            elif xv!=yv: trade_match=False; break
          if not trade_match: break
      modes[mode]={
        'summary_match_exact': bool(summary_match),
        'trade_level_match_on_common_fields': bool(trade_match),
        'audited': {k:v[0] for k,v in summary_fields.items()},
        'independent_hbt_format_replay': {k:v[1] for k,v in summary_fields.items()},
      }
    report[name]={'conversion_integrity':integrity,'modes':modes}

out=HERE/'validation_report.json'; out.write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
