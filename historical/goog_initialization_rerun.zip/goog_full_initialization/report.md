# Initialization diagnosis and rerun

Initialization is the first 30 resolved historical first-passage outcomes entering the expanding empirical distribution. It is not model training.

## GOOG

The earlier quick test used only the first 50,000 updates of July 1 and requested 100-share execution from an L1 feed. It produced 535 candidate anchors, but 422 lacked 100 shares on both hypothetical entry sides, 85 had no post-latency observation before the 50-update deadline, and only 28 outcomes matured before the last forecast. It therefore stopped two observations short of the fixed warmup of 30.

The clean rerun uses all 2,981,357 updates from June 11, chronological expanding history, 5 ms latency, the fixed 50-update proxy window, the same cost model, and the no-crossing action rule.

| Size and conditioning | Anchors | Usable labels | Final matured history | Initialized forecasts | Trades | Net PnL |
|---|---:|---:|---:|---:|---:|---:|
| 100 shares, imbalance | 66,806 | 2,042 | 2,040 | 65,689 | 0 | $0 |
| 100 shares, imbalance + state | 66,806 | 2,042 | 2,040 | 65,689 | 0 | $0 |
| 1 share, imbalance + state | 66,806 | 61,813 | 61,810 | 66,744 | 0 | $0 |

At 100 shares, 59,771 anchors lacked displayed entry depth, 4,993 had no post-latency observation inside 50 book updates, 2,012 timed out as state zero, and 30 reached a fee-covering first passage. At one share, insufficient depth disappeared: 60,624 timed out, 1,189 hit, and 4,993 remained unavailable because 50 book updates passed in under the configured 5 ms latency.

Every initialized forecast in all three reruns was vetoed because p0 was at least as large as both directional probabilities. Full-day data fixes initialization, but does not produce a trade under the declared no-crossing rule.

The GOOG clock is book updates, not exchange trades. The 50-count window is therefore a proxy and can expire in less than 5 ms. The source is L1 only, so the 100-share test cannot see executable liquidity beyond the best level. Across available days, median displayed best-level size is roughly 27 to 66 shares; both sides simultaneously display at least 100 shares in only about 3% to 15% of rows.

## Infosys

Rerunning the complete available 10,000-snapshot file gives the same result for both conditioning variants: 44 candidate anchors, 24 hits, 19 observation-gap censures, one insufficient-depth censure, maximum matured history 22, zero initialized forecasts, and zero trades.

The file contains 300 invalid book rows: 104 empty top levels, 103 locked or crossed books, and 93 incorrectly ordered price levels. If one appears between entry and resolution, the label is censored rather than silently treating the window as state zero. The source simply does not contain 30 trustworthy resolved observations under the fixed setup.

## Verification

The expanding spread percentile was reimplemented as an exact causal order statistic so multi-million-row files finish in practical time. A regression test verifies equality with Pandas under missing values and ties. All 53 tests pass. The strategy definition, probability calculation, warmup, latency, first-passage label, and action rule were unchanged.
