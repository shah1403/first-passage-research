from pathlib import Path

import numpy as np
import pandas as pd

from goog_dynamic_stock_test import load_goog
from goog_event_study import add_setup_features
from kalshi_probability_sizing import drawdown


OUT = Path("high_fidelity_replay")
OUT.mkdir(exist_ok=True)

GOOG_FEE_PER_SHARE = 0.0035
# Conservative placeholder until exact NSE brokerage/STT/exchange/GST schedule is wired in.
NSE_COST_BPS_PER_SIDE = 1.0
HORIZONS_MS = [250, 500, 1000, 2500, 5000, 10000]
LATENCIES_MS = [0, 5, 50, 100, 250, 500]
GOOG_SIZES = [1, 10, 50, 100]
NSE_SIZES = [1, 10, 50, 100, 500]
WARMUP = 30


def _edges(x, bins=5):
    vals = x[np.isfinite(x)]
    e = np.unique(np.quantile(vals, np.linspace(0, 1, bins + 1)))
    if len(e) < 2:
        e = np.array([-np.inf, np.inf])
    e[0], e[-1] = -np.inf, np.inf
    return e


def _causal_percentile(values):
    s = pd.Series(values, dtype=float)
    q25 = s.expanding(min_periods=20).quantile(0.25)
    return np.where(s <= q25, 0.25, 1.0)


def _causal_buckets(values, bins=5):
    s = pd.Series(values, dtype=float)
    qs = [k / bins for k in range(1, bins)]
    cuts = [s.expanding(min_periods=20).quantile(q).to_numpy() for q in qs]
    out = np.zeros(len(values), dtype=int)
    for k, c in enumerate(cuts):
        out += np.asarray(values) > c
    return out


def _add_causal_microstructure_features(df):
    d = df.copy()
    d["abs_imb"] = d.imb1.abs()
    d["imb_sign"] = np.sign(d.imb1)
    group_keys = ["date"] if "date" in d.columns else [None]
    parts = []
    groups = d.groupby("date", sort=False) if "date" in d.columns else [(None, d)]
    for _, g0 in groups:
        g = g0.copy()
        g["spread_rank"] = _causal_percentile(g.spread.to_numpy())
        g["imb_bucket_causal"] = _causal_buckets(g.imb1.to_numpy())
        for lb in [10]:
            b = g.imb_bucket_causal.to_numpy()
            stable = []
            for i in range(len(g)):
                lo = max(0, i - lb + 1)
                stable.append(int(np.all(b[lo : i + 1] == b[i])))
            g[f"stable_bucket_{lb}"] = stable
        parts.append(g)
    return pd.concat(parts).sort_index()


def _bucket(e, value):
    return int(np.searchsorted(e, value, side="right") - 1)


def _update_counts(counts, key, y):
    if key not in counts:
        counts[key] = np.zeros(3)
    counts[key][{-1: 0, 0: 1, 1: 2}[int(y)]] += 1


def _probs(counts, key):
    c = counts.get(key)
    if c is None or c.sum() < 5:
        c = counts.get(("all",), np.zeros(3))
    return (c + 0.5) / (c.sum() + 1.5)


def _key(r, mode):
    if mode == "sign":
        return (int(r.imb_sign),)
    if mode == "bucket":
        return (int(r.imb_bucket),)
    if mode == "sign_prev":
        return (int(r.imb_sign), int(r.prev_y))
    if mode == "bucket_prev":
        return (int(r.imb_bucket), int(r.prev_y))
    return ("all",)


def load_goog_days():
    df = _add_causal_microstructure_features(load_goog())
    df = df.sort_values(["date", "ts"]).reset_index(drop=True)
    return df


def build_goog_anchors(df):
    rows = []
    for date, g0 in df.groupby("date", sort=False):
        g = g0.reset_index(drop=False).rename(columns={"index": "global_i"})
        setup = (g.abs_imb >= 0.8) & (g.spread_rank <= 0.25) & (g.stable_bucket_10 == 1)
        for i in np.arange(0, len(g), 5):
            i = int(i)
            if not bool(setup.iat[i]):
                continue
            for h in HORIZONS_MS:
                end = np.searchsorted(g.ts.to_numpy(), int(g.ts.iat[i] + h), side="right")
                if end <= i + 1:
                    continue
                rows.append(
                    {
                        "date": date,
                        "local_i": i,
                        "global_i": int(g.global_i.iat[i]),
                        "horizon_ms": h,
                        "ts": int(g.ts.iat[i]),
                        "imb1": float(g.imb1.iat[i]),
                        "imb_sign": int(np.sign(g.imb1.iat[i])),
                        "imb_bucket": int(g.imb_bucket_causal.iat[i]),
                    }
                )
    anchors = pd.DataFrame(rows).sort_values(["date", "ts", "horizon_ms"]).reset_index(drop=True)
    return anchors


def executable_fill_price(side, q, bid, ask, bq, aq):
    if side == 1:
        if aq < q:
            return None
        return ask
    if bq < q:
        return None
    return bid


def exit_price(side, q, bid, ask, bq, aq):
    if side == 1:
        if bq < q:
            return None
        return bid
    if aq < q:
        return None
    return ask


def first_passage_state_from_anchor(df, anchor_i, horizon_ms, latency_ms):
    ts = df.ts.to_numpy()
    end = np.searchsorted(ts, int(df.ts.iat[anchor_i] + horizon_ms), side="right")
    if end <= anchor_i + 1:
        return 0
    ask0 = float(df.ask.iat[anchor_i])
    bid0 = float(df.bid.iat[anchor_i])
    for j in range(anchor_i + 1, end):
        exit_i = np.searchsorted(ts, int(df.ts.iat[j] + latency_ms), side="left")
        if exit_i >= len(df) or df.date.iat[exit_i] != df.date.iat[anchor_i] or exit_i >= end:
            continue
        long_pnl = float(df.bid.iat[exit_i]) - ask0 - 2 * GOOG_FEE_PER_SHARE
        short_pnl = bid0 - float(df.ask.iat[exit_i]) - 2 * GOOG_FEE_PER_SHARE
        if long_pnl > 0 or short_pnl > 0:
            return 1 if long_pnl >= short_pnl else -1
    return 0


def replay_goog(df, anchors, mode, latency_ms, q, horizon_ms):
    ev = anchors[anchors.horizon_ms == horizon_ms].sort_values(["date", "ts"]).copy().reset_index(drop=True)
    if len(ev) <= WARMUP:
        return None, pd.DataFrame()
    # Labels are only for updating the rolling distribution after the event is knowable.
    ev["y"] = [first_passage_state_from_anchor(df, int(i), horizon_ms, latency_ms) for i in ev.global_i]
    ev["prev_y"] = ev.y.shift(1).fillna(0).astype(int)
    counts = {}
    for r in ev.iloc[:WARMUP].itertuples(index=False):
        _update_counts(counts, ("all",), r.y)
        _update_counts(counts, _key(r, mode), r.y)

    cash = 0.0
    equity = [0.0]
    trades = []
    next_allowed_ts = -1
    ts_arr = df.ts.to_numpy()
    for r in ev.iloc[WARMUP:].itertuples(index=False):
        if r.ts < next_allowed_ts:
            _update_counts(counts, ("all",), r.y)
            _update_counts(counts, _key(r, mode), r.y)
            continue
        pminus, pzero, pplus = _probs(counts, _key(r, mode))
        side = 1 if pplus >= pminus else -1
        exec_ts = int(r.ts + latency_ms)
        entry_i = np.searchsorted(ts_arr, exec_ts, side="left")
        if entry_i >= len(df) or df.date.iat[entry_i] != r.date:
            _update_counts(counts, ("all",), r.y)
            _update_counts(counts, _key(r, mode), r.y)
            continue
        entry = executable_fill_price(
            side,
            q,
            float(df.bid.iat[entry_i]),
            float(df.ask.iat[entry_i]),
            float(df.bq.iat[entry_i]),
            float(df.aq.iat[entry_i]),
        )
        if entry is None:
            _update_counts(counts, ("all",), r.y)
            _update_counts(counts, _key(r, mode), r.y)
            continue

        end = np.searchsorted(ts_arr, int(r.ts + horizon_ms), side="right")
        exit_i = None
        px_out = None
        for j in range(entry_i + 1, min(end, len(df))):
            if df.date.iat[j] != r.date:
                break
            px = exit_price(side, q, float(df.bid.iat[j]), float(df.ask.iat[j]), float(df.bq.iat[j]), float(df.aq.iat[j]))
            if px is None:
                continue
            pnl1 = (px - entry) if side == 1 else (entry - px)
            if pnl1 - 2 * GOOG_FEE_PER_SHARE > 0:
                delayed_j = np.searchsorted(ts_arr, int(df.ts.iat[j] + latency_ms), side="left")
                if delayed_j >= len(df) or delayed_j >= end or df.date.iat[delayed_j] != r.date:
                    continue
                delayed_px = exit_price(side, q, float(df.bid.iat[delayed_j]), float(df.ask.iat[delayed_j]), float(df.bq.iat[delayed_j]), float(df.aq.iat[delayed_j]))
                if delayed_px is None:
                    continue
                delayed_pnl1 = (delayed_px - entry) if side == 1 else (entry - delayed_px)
                if delayed_pnl1 - 2 * GOOG_FEE_PER_SHARE > 0:
                    exit_i, px_out = delayed_j, delayed_px
                    break
        if exit_i is None:
            j = min(end - 1, len(df) - 1)
            if j > entry_i and df.date.iat[j] == r.date:
                px_out = exit_price(side, q, float(df.bid.iat[j]), float(df.ask.iat[j]), float(df.bq.iat[j]), float(df.aq.iat[j]))
                exit_i = j if px_out is not None else None
        if exit_i is None:
            _update_counts(counts, ("all",), r.y)
            _update_counts(counts, _key(r, mode), r.y)
            continue
        pnl = q * ((px_out - entry) if side == 1 else (entry - px_out)) - 2 * GOOG_FEE_PER_SHARE * q
        cash += pnl
        equity.append(cash)
        next_allowed_ts = int(df.ts.iat[exit_i])
        trades.append(
            {
                "asset": "GOOG",
                "mode": mode,
                "horizon_ms": horizon_ms,
                "latency_ms": latency_ms,
                "q": q,
                "date": r.date,
                "anchor_ts": r.ts,
                "entry_ts": int(df.ts.iat[entry_i]),
                "exit_ts": int(df.ts.iat[exit_i]),
                "side": side,
                "pminus": pminus,
                "pzero": pzero,
                "pplus": pplus,
                "entry": entry,
                "exit": px_out,
                "pnl": pnl,
                "cash": cash,
            }
        )
        _update_counts(counts, ("all",), r.y)
        _update_counts(counts, _key(r, mode), r.y)
    t = pd.DataFrame(trades)
    summary = {
        "asset": "GOOG",
        "mode": mode,
        "horizon_ms": horizon_ms,
        "latency_ms": latency_ms,
        "q": q,
        "anchors": len(ev),
        "trades": len(t),
        "net": float(t.pnl.sum()) if len(t) else 0.0,
        "mean_trade": float(t.pnl.mean()) if len(t) else np.nan,
        "median_trade": float(t.pnl.median()) if len(t) else np.nan,
        "max_drawdown": drawdown(np.r_[0, t.pnl.cumsum()]) if len(t) else 0.0,
    }
    return summary, t


def run_goog():
    df = load_goog_days()
    anchors = build_goog_anchors(df)
    summaries = []
    trades = []
    for h in HORIZONS_MS:
        for mode in ["sign", "bucket", "sign_prev", "bucket_prev"]:
            for lat in LATENCIES_MS:
                for q in GOOG_SIZES:
                    s, t = replay_goog(df, anchors, mode, lat, q, h)
                    if s is not None:
                        summaries.append(s)
                        if len(t):
                            trades.append(t)
    pd.DataFrame(summaries).to_csv(OUT / "goog_high_fidelity_summary.csv", index=False)
    if trades:
        pd.concat(trades, ignore_index=True).to_csv(OUT / "goog_high_fidelity_trades.csv", index=False)
    return pd.DataFrame(summaries)


def load_nse_file(path):
    z = np.load(path)
    bids = z["bids"].astype(float)
    asks = z["asks"].astype(float)
    sym = str(z["symbol"])
    df = pd.DataFrame(
        {
            "symbol": sym,
            "ts": z["ts"].astype(np.int64),
            "bid": bids[:, 0, 0],
            "ask": asks[:, 0, 0],
            "bq": bids[:, 0, 1],
            "aq": asks[:, 0, 1],
            "bid5q": bids[:, :, 1].sum(axis=1),
            "ask5q": asks[:, :, 1].sum(axis=1),
        }
    )
    valid = (df.ask > df.bid) & (df.bid > 0) & (df.ask > 0)
    bids = bids[valid.to_numpy()]
    asks = asks[valid.to_numpy()]
    df = df[valid].copy().reset_index(drop=True)
    df["mid"] = (df.bid + df.ask) / 2
    df["spread"] = df.ask - df.bid
    df["imb1"] = (df.bq - df.aq) / np.maximum(df.bq + df.aq, 1e-12)
    df = _add_causal_microstructure_features(df)
    return sym, df, bids, asks


def nse_market_price(book_side, q):
    remaining = float(q)
    notional = 0.0
    for price, qty in book_side:
        take = min(remaining, float(qty))
        notional += take * float(price)
        remaining -= take
        if remaining <= 1e-9:
            return notional / q
    return None


def build_nse_anchors(symbol, df):
    mask = (df.abs_imb >= 0.8) & (df.spread_rank <= 0.25)
    rows = []
    for i in np.arange(0, len(df), 5):
        i = int(i)
        if not bool(mask.iat[i]):
            continue
        for h in [5000, 10000, 30000, 60000]:
            end = np.searchsorted(df.ts.to_numpy(), int(df.ts.iat[i] + h), side="right")
            if end > i + 1:
                rows.append(
                    {
                        "symbol": symbol,
                        "i": i,
                        "ts": int(df.ts.iat[i]),
                        "horizon_ms": h,
                        "imb1": float(df.imb1.iat[i]),
                        "imb_sign": int(np.sign(df.imb1.iat[i])),
                        "imb_bucket": int(df.imb_bucket_causal.iat[i]),
                    }
                )
    return pd.DataFrame(rows).sort_values(["ts", "horizon_ms"]).reset_index(drop=True)


def _nse_cost(entry, exit_px, q):
    return (NSE_COST_BPS_PER_SIDE / 10000.0) * q * (entry + exit_px)


def nse_label(df, bids, asks, i, h, latency_ms):
    ts = df.ts.to_numpy()
    end = np.searchsorted(ts, int(df.ts.iat[i] + h), side="right")
    if end <= i + 1:
        return 0
    long_entry = asks[i, 0, 0]
    short_entry = bids[i, 0, 0]
    for j in range(i + 1, end):
        exit_i = np.searchsorted(ts, int(df.ts.iat[j] + latency_ms), side="left")
        if exit_i >= end:
            continue
        lp = bids[exit_i, 0, 0] - long_entry
        sp = short_entry - asks[exit_i, 0, 0]
        if lp > 0 or sp > 0:
            return 1 if lp >= sp else -1
    return 0


def replay_nse_one(symbol, df, bids, asks, anchors, mode, latency_ms, q, horizon_ms):
    ev = anchors[anchors.horizon_ms == horizon_ms].copy().reset_index(drop=True)
    if len(ev) <= WARMUP:
        return None, pd.DataFrame()
    ev["y"] = [nse_label(df, bids, asks, int(i), horizon_ms, latency_ms) for i in ev.i]
    ev["prev_y"] = ev.y.shift(1).fillna(0).astype(int)
    counts = {}
    for r in ev.iloc[:WARMUP].itertuples(index=False):
        _update_counts(counts, ("all",), r.y)
        _update_counts(counts, _key(r, mode), r.y)
    trades = []
    cash = 0.0
    ts_arr = df.ts.to_numpy()
    next_allowed_ts = -1
    for r in ev.iloc[WARMUP:].itertuples(index=False):
        if r.ts < next_allowed_ts:
            _update_counts(counts, ("all",), r.y)
            _update_counts(counts, _key(r, mode), r.y)
            continue
        pminus, pzero, pplus = _probs(counts, _key(r, mode))
        side = 1 if pplus >= pminus else -1
        entry_i = np.searchsorted(ts_arr, int(r.ts + latency_ms), side="left")
        if entry_i >= len(df):
            _update_counts(counts, ("all",), r.y)
            _update_counts(counts, _key(r, mode), r.y)
            continue
        entry = nse_market_price(asks[entry_i], q) if side == 1 else nse_market_price(bids[entry_i], q)
        if entry is None:
            _update_counts(counts, ("all",), r.y)
            _update_counts(counts, _key(r, mode), r.y)
            continue
        end = np.searchsorted(ts_arr, int(r.ts + horizon_ms), side="right")
        exit_i = None
        px_out = None
        for j in range(entry_i + 1, min(end, len(df))):
            px = nse_market_price(bids[j], q) if side == 1 else nse_market_price(asks[j], q)
            if px is None:
                continue
            pnl1 = (px - entry) if side == 1 else (entry - px)
            if q * pnl1 - _nse_cost(entry, px, q) > 0:
                delayed_j = np.searchsorted(ts_arr, int(df.ts.iat[j] + latency_ms), side="left")
                if delayed_j >= len(df) or delayed_j >= end:
                    continue
                delayed_px = nse_market_price(bids[delayed_j], q) if side == 1 else nse_market_price(asks[delayed_j], q)
                if delayed_px is None:
                    continue
                delayed_pnl1 = (delayed_px - entry) if side == 1 else (entry - delayed_px)
                if q * delayed_pnl1 - _nse_cost(entry, delayed_px, q) > 0:
                    exit_i, px_out = delayed_j, delayed_px
                    break
        if exit_i is None and end - 1 > entry_i:
            j = min(end - 1, len(df) - 1)
            px_out = nse_market_price(bids[j], q) if side == 1 else nse_market_price(asks[j], q)
            exit_i = j if px_out is not None else None
        if exit_i is not None:
            pnl = q * ((px_out - entry) if side == 1 else (entry - px_out)) - _nse_cost(entry, px_out, q)
            cash += pnl
            next_allowed_ts = int(df.ts.iat[exit_i])
            trades.append(
                {
                    "asset": symbol,
                    "mode": mode,
                    "horizon_ms": horizon_ms,
                    "latency_ms": latency_ms,
                    "q": q,
                    "entry": entry,
                    "exit": px_out,
                    "side": side,
                    "pnl": pnl,
                    "cash": cash,
                }
            )
        _update_counts(counts, ("all",), r.y)
        _update_counts(counts, _key(r, mode), r.y)
    t = pd.DataFrame(trades)
    return {
        "asset": symbol,
        "mode": mode,
        "horizon_ms": horizon_ms,
        "latency_ms": latency_ms,
        "q": q,
        "anchors": len(ev),
        "trades": len(t),
        "net": float(t.pnl.sum()) if len(t) else 0.0,
        "mean_trade": float(t.pnl.mean()) if len(t) else np.nan,
        "median_trade": float(t.pnl.median()) if len(t) else np.nan,
        "max_drawdown": drawdown(np.r_[0, t.pnl.cumsum()]) if len(t) else 0.0,
    }, t


def run_nse():
    summaries = []
    trades = []
    for p in sorted(Path("upload").glob("orderbook_*_10000snaps.npz")):
        symbol, df, bids, asks = load_nse_file(p)
        anchors = build_nse_anchors(symbol, df)
        for h in [5000, 10000, 30000, 60000]:
            for mode in ["sign", "bucket", "sign_prev", "bucket_prev"]:
                for lat in LATENCIES_MS:
                    for q in NSE_SIZES:
                        s, t = replay_nse_one(symbol, df, bids, asks, anchors, mode, lat, q, h)
                        if s is not None:
                            summaries.append(s)
                            if len(t):
                                trades.append(t)
    pd.DataFrame(summaries).to_csv(OUT / "nse_high_fidelity_summary.csv", index=False)
    if trades:
        pd.concat(trades, ignore_index=True).to_csv(OUT / "nse_high_fidelity_trades.csv", index=False)
    return pd.DataFrame(summaries)


def main():
    goog = run_goog()
    nse = run_nse()
    print("GOOG")
    print(goog.sort_values("net", ascending=False).head(20).to_string(index=False))
    print("\nNSE")
    print(nse.sort_values("net", ascending=False).head(20).to_string(index=False))


if __name__ == "__main__":
    main()
