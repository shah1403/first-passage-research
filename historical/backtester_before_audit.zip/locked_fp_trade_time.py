from pathlib import Path

import numpy as np
import pandas as pd

from high_fidelity_replay import (
    GOOG_FEE_PER_SHARE,
    NSE_COST_BPS_PER_SIDE,
    OUT,
    WARMUP,
    _nse_cost,
    _probs,
    _update_counts,
    build_goog_anchors,
    build_nse_anchors,
    executable_fill_price,
    exit_price,
    load_goog_days,
    load_nse_file,
    nse_market_price,
)
from kalshi_probability_sizing import drawdown


LATENCY_EVENTS = 1
LOCKED_MAX_EVENTS = 50
GOOG_Q = 100
NSE_Q = 100
DIAGNOSTIC_MAX_EVENTS = [10, 25, 50, 100, 250]


def _signal_key(r):
    return ("imb_bucket", int(r.imb_bucket))


def _update_signal_counts(counts, r):
    _update_counts(counts, ("all",), r.y)
    _update_counts(counts, _signal_key(r), r.y)


def _side_from_conditioned_history(counts, r):
    pminus, pzero, pplus = _probs(counts, _signal_key(r))
    return (1 if pplus >= pminus else -1), pminus, pzero, pplus


def _summarize(asset, split, max_events, q, trades, anchors):
    t = pd.DataFrame(trades)
    return {
        "asset": asset,
        "split": split,
        "signal": "rolling_imbalance_conditioned_first_passage_trade_time",
        "max_events": max_events,
        "latency_events": LATENCY_EVENTS,
        "q": q,
        "anchors": anchors,
        "trades": len(t),
        "net": float(t.pnl.sum()) if len(t) else 0.0,
        "mean_trade": float(t.pnl.mean()) if len(t) else np.nan,
        "median_trade": float(t.pnl.median()) if len(t) else np.nan,
        "max_drawdown": drawdown(np.r_[0, t.pnl.cumsum()]) if len(t) else 0.0,
        "avg_wait_ms": float(t.wait_ms.mean()) if len(t) else np.nan,
        "median_wait_ms": float(t.wait_ms.median()) if len(t) else np.nan,
        "p90_wait_ms": float(t.wait_ms.quantile(0.9)) if len(t) else np.nan,
    }


def goog_label_trade_time(df, anchor_i, max_events):
    end = min(anchor_i + max_events + 1, len(df))
    entry_i = anchor_i + LATENCY_EVENTS
    if end <= entry_i + 1 or entry_i >= len(df):
        return 0
    ask0 = float(df.ask.iat[entry_i])
    bid0 = float(df.bid.iat[entry_i])
    date = df.date.iat[anchor_i]
    if df.date.iat[entry_i] != date:
        return 0
    for j in range(entry_i + 1, end):
        exit_i = min(j + LATENCY_EVENTS, end - 1)
        if df.date.iat[exit_i] != date:
            break
        long_pnl = float(df.bid.iat[exit_i]) - ask0 - 2 * GOOG_FEE_PER_SHARE
        short_pnl = bid0 - float(df.ask.iat[exit_i]) - 2 * GOOG_FEE_PER_SHARE
        if long_pnl > 0 or short_pnl > 0:
            return 1 if long_pnl >= short_pnl else -1
    return 0


def build_goog_trade_time_events(df, max_events):
    base = build_goog_anchors(df)
    first = base.drop_duplicates(["date", "global_i"]).copy()
    rows = []
    for r in first.itertuples(index=False):
        if int(r.global_i) + 1 >= len(df):
            continue
        if df.date.iat[int(r.global_i)] != r.date:
            continue
        rows.append(
            {
                "date": r.date,
                "global_i": int(r.global_i),
                "ts": int(r.ts),
                "imb_bucket": int(r.imb_bucket),
                "imb_sign": int(r.imb_sign),
                "max_events": max_events,
                "y": goog_label_trade_time(df, int(r.global_i), max_events),
            }
        )
    ev = pd.DataFrame(rows).sort_values(["date", "ts"]).reset_index(drop=True)
    ev["prev_y"] = ev.y.shift(1).fillna(0).astype(int) if len(ev) else []
    return ev


def _replay_goog(df, events, counts, max_events, q, split):
    trades = []
    cash = 0.0
    next_allowed_i = -1
    for r in events.itertuples(index=False):
        if r.global_i < next_allowed_i:
            _update_signal_counts(counts, r)
            continue
        side, pminus, pzero, pplus = _side_from_conditioned_history(counts, r)
        entry_i = int(r.global_i) + LATENCY_EVENTS
        if entry_i >= len(df) or df.date.iat[entry_i] != r.date:
            _update_signal_counts(counts, r)
            continue
        entry = executable_fill_price(
            side,
            q,
            float(df.bid.iat[entry_i]),
            float(df.ask.iat[entry_i]),
            float(df.bq.iat[entry_i]),
            float(df.aq.iat[entry_i]),
        )
        if entry is None:
            _update_signal_counts(counts, r)
            continue
        end = min(int(r.global_i) + max_events + 1, len(df))
        exit_i = None
        px_out = None
        for j in range(entry_i + 1, end):
            if df.date.iat[j] != r.date:
                break
            px = exit_price(side, q, float(df.bid.iat[j]), float(df.ask.iat[j]), float(df.bq.iat[j]), float(df.aq.iat[j]))
            if px is None:
                continue
            pnl1 = (px - entry) if side == 1 else (entry - px)
            if pnl1 - 2 * GOOG_FEE_PER_SHARE <= 0:
                continue
            delayed_j = min(j + LATENCY_EVENTS, end - 1)
            if df.date.iat[delayed_j] != r.date:
                continue
            delayed_px = exit_price(
                side,
                q,
                float(df.bid.iat[delayed_j]),
                float(df.ask.iat[delayed_j]),
                float(df.bq.iat[delayed_j]),
                float(df.aq.iat[delayed_j]),
            )
            if delayed_px is None:
                continue
            delayed_pnl1 = (delayed_px - entry) if side == 1 else (entry - delayed_px)
            if delayed_pnl1 - 2 * GOOG_FEE_PER_SHARE > 0:
                exit_i, px_out = delayed_j, delayed_px
                break
        if exit_i is None:
            j = min(end - 1, len(df) - 1)
            if j > entry_i and df.date.iat[j] == r.date:
                px_out = exit_price(side, q, float(df.bid.iat[j]), float(df.ask.iat[j]), float(df.bq.iat[j]), float(df.aq.iat[j]))
                exit_i = j if px_out is not None else None
        if exit_i is not None:
            pnl = q * ((px_out - entry) if side == 1 else (entry - px_out)) - 2 * GOOG_FEE_PER_SHARE * q
            cash += pnl
            next_allowed_i = exit_i
            trades.append(
                {
                    "asset": "GOOG",
                    "split": split,
                    "max_events": max_events,
                    "q": q,
                    "date": r.date,
                    "anchor_i": int(r.global_i),
                    "entry_i": entry_i,
                    "exit_i": exit_i,
                    "anchor_ts": int(r.ts),
                    "entry_ts": int(df.ts.iat[entry_i]),
                    "exit_ts": int(df.ts.iat[exit_i]),
                    "wait_events": int(exit_i - int(r.global_i)),
                    "wait_ms": int(df.ts.iat[exit_i] - r.ts),
                    "side": side,
                    "pminus": pminus,
                    "pzero": pzero,
                    "pplus": pplus,
                    "entry": entry,
                    "exit": px_out,
                    "pnl": pnl,
                    "cash": cash,
                }
            )
        _update_signal_counts(counts, r)
    return _summarize("GOOG", split, max_events, q, trades, len(events)), pd.DataFrame(trades)


def run_goog(max_events):
    df = load_goog_days()
    ev = build_goog_trade_time_events(df, max_events)
    june = ev[ev.date.astype(str).str.startswith("2026-06")].copy()
    july = ev[ev.date.astype(str).str.startswith("2026-07")].copy()
    counts = {}
    for r in june.itertuples(index=False):
        _update_signal_counts(counts, r)
    return _replay_goog(df, july, counts, max_events, GOOG_Q, "test")


def nse_label_trade_time(df, bids, asks, anchor_i, max_events):
    end = min(anchor_i + max_events + 1, len(df))
    entry_i = anchor_i + LATENCY_EVENTS
    if end <= entry_i + 1 or entry_i >= len(df):
        return 0
    long_entry = asks[entry_i, 0, 0]
    short_entry = bids[entry_i, 0, 0]
    for j in range(entry_i + 1, end):
        exit_i = min(j + LATENCY_EVENTS, end - 1)
        lp = bids[exit_i, 0, 0] - long_entry
        sp = short_entry - asks[exit_i, 0, 0]
        if lp > 0 or sp > 0:
            return 1 if lp >= sp else -1
    return 0


def build_nse_trade_time_events(symbol, df, max_events):
    base = build_nse_anchors(symbol, df)
    first = base.drop_duplicates("i").copy()
    rows = []
    for r in first.itertuples(index=False):
        if int(r.i) + 1 >= len(df):
            continue
        rows.append(
            {
                "symbol": symbol,
                "i": int(r.i),
                "ts": int(r.ts),
                "imb_bucket": int(r.imb_bucket),
                "imb_sign": int(r.imb_sign),
                "max_events": max_events,
            }
        )
    ev = pd.DataFrame(rows).sort_values("ts").reset_index(drop=True)
    return ev


def _replay_nse(symbol, df, bids, asks, events, counts, max_events, q, split):
    trades = []
    cash = 0.0
    next_allowed_i = -1
    for r in events.itertuples(index=False):
        if r.i < next_allowed_i:
            _update_signal_counts(counts, r)
            continue
        side, pminus, pzero, pplus = _side_from_conditioned_history(counts, r)
        entry_i = int(r.i) + LATENCY_EVENTS
        if entry_i >= len(df):
            _update_signal_counts(counts, r)
            continue
        entry = nse_market_price(asks[entry_i], q) if side == 1 else nse_market_price(bids[entry_i], q)
        if entry is None:
            _update_signal_counts(counts, r)
            continue
        end = min(int(r.i) + max_events + 1, len(df))
        exit_i = None
        px_out = None
        for j in range(entry_i + 1, end):
            px = nse_market_price(bids[j], q) if side == 1 else nse_market_price(asks[j], q)
            if px is None:
                continue
            pnl1 = (px - entry) if side == 1 else (entry - px)
            if q * pnl1 - _nse_cost(entry, px, q) <= 0:
                continue
            delayed_j = min(j + LATENCY_EVENTS, end - 1)
            delayed_px = nse_market_price(bids[delayed_j], q) if side == 1 else nse_market_price(asks[delayed_j], q)
            if delayed_px is None:
                continue
            delayed_pnl1 = (delayed_px - entry) if side == 1 else (entry - delayed_px)
            if q * delayed_pnl1 - _nse_cost(entry, delayed_px, q) > 0:
                exit_i, px_out = delayed_j, delayed_px
                break
        if exit_i is None and end - 1 > entry_i:
            j = min(end - 1, len(df) - 1)
            px_out = nse_market_price(bids[j], q) if side == 1 else nse_market_price(asks[j], q)
            exit_i = j if px_out is not None else None
        if exit_i is not None:
            pnl = q * ((px_out - entry) if side == 1 else (entry - px_out)) - _nse_cost(entry, px_out, q)
            cash += pnl
            next_allowed_i = exit_i
            trades.append(
                {
                    "asset": symbol,
                    "split": split,
                    "max_events": max_events,
                    "q": q,
                    "anchor_i": int(r.i),
                    "entry_i": entry_i,
                    "exit_i": exit_i,
                    "anchor_ts": int(r.ts),
                    "entry_ts": int(df.ts.iat[entry_i]),
                    "exit_ts": int(df.ts.iat[exit_i]),
                    "wait_events": int(exit_i - int(r.i)),
                    "wait_ms": int(df.ts.iat[exit_i] - r.ts),
                    "side": side,
                    "pminus": pminus,
                    "pzero": pzero,
                    "pplus": pplus,
                    "entry": entry,
                    "exit": px_out,
                    "pnl": pnl,
                    "cash": cash,
                }
            )
        _update_signal_counts(counts, r)
    return _summarize(symbol, split, max_events, q, trades, len(events)), pd.DataFrame(trades)


def run_nse(max_events):
    summaries = []
    trades = []
    for path in sorted(Path("upload").glob("orderbook_*_10000snaps.npz")):
        symbol, df, bids, asks = load_nse_file(path)
        ev = build_nse_trade_time_events(symbol, df, max_events)
        if len(ev) <= WARMUP + 5:
            continue
        ev["y"] = [nse_label_trade_time(df, bids, asks, int(i), max_events) for i in ev.i]
        ev["prev_y"] = ev.y.shift(1).fillna(0).astype(int)
        split_i = max(WARMUP, int(len(ev) * 0.7))
        train_ev = ev.iloc[:split_i].copy()
        test_ev = ev.iloc[split_i:].copy()
        counts = {}
        for r in train_ev.itertuples(index=False):
            _update_signal_counts(counts, r)
        s, t = _replay_nse(symbol, df, bids, asks, test_ev, counts, max_events, NSE_Q, "test")
        summaries.append(s)
        if len(t):
            trades.append(t)
    return summaries, pd.concat(trades, ignore_index=True) if trades else pd.DataFrame()


def run_all(max_events):
    summaries = []
    trade_frames = []
    gs, gt = run_goog(max_events)
    summaries.append(gs)
    if len(gt):
        trade_frames.append(gt)
    ns, nt = run_nse(max_events)
    summaries.extend(ns)
    if len(nt):
        trade_frames.append(nt)
    return summaries, pd.concat(trade_frames, ignore_index=True) if trade_frames else pd.DataFrame()


def main():
    OUT.mkdir(exist_ok=True)
    summaries, trades = run_all(LOCKED_MAX_EVENTS)
    summary = pd.DataFrame(summaries)
    summary.to_csv(OUT / "locked_fp_trade_time_summary.csv", index=False)
    trades.to_csv(OUT / "locked_fp_trade_time_trades.csv", index=False)
    diag_rows = []
    for n in DIAGNOSTIC_MAX_EVENTS:
        diag_rows.extend(run_all(n)[0])
    diag = pd.DataFrame(diag_rows)
    diag.to_csv(OUT / "locked_fp_trade_time_diagnostics.csv", index=False)
    print("LOCKED_TRADE_TIME")
    print(summary.to_string(index=False))
    print("\nTRADE_TIME_DIAGNOSTICS_NOT_SELECTION")
    print(diag.to_string(index=False))
    print(f"\nNSE cost placeholder: {NSE_COST_BPS_PER_SIDE} bps per side")


if __name__ == "__main__":
    main()
