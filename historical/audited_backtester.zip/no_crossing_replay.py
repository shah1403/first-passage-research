"""Fixed-scope replay: state zero and all probability ties veto entry."""
from dataclasses import asdict
from functools import lru_cache
import hashlib
import json
from pathlib import Path

import numpy as np
import audited_fp as engine
from audited_fp import Config, Fees, History, replay
from audited_fp_runner import load_nse, load_kalshi
from quick_fp_diagnosis import goog_sample, exit_arrays, diagnose, oracle

OUT = Path("no_crossing_replay")
def json_default(value):
    if isinstance(value, np.generic):
        return value.item()
    raise TypeError(type(value).__name__)

JOBS = [
    ("INFY", "nse", "upload/orderbook_infy_10000snaps.npz", 100, Fees("nse_intraday")),
    ("TATAMOTORS", "nse", "upload/orderbook_tatamotors_10000snaps.npz", 100, Fees("nse_intraday")),
    ("BTC15M", "kalshi", "quant_results/kalshi-btc15m-2026-09-11.txt.zst.features.csv.gz", 1, Fees("kalshi")),
    ("NFL", "kalshi", "sports_v4/NFL/features.csv.gz", 1, Fees("kalshi")),
    ("MLB", "kalshi", "sports_v4/MLB/features.csv.gz", 1, Fees("kalshi")),
    ("GOOG", "goog", "upload/goog_2026-07-01.npz", 100, Fees("per_share", per_share=.0035)),
]


def main():
    OUT.mkdir(exist_ok=True)
    summaries = []
    original = engine.accounting
    for name, kind, path, q, fees in JOBS:
        tapes = load_nse(path) if kind == "nse" else load_kalshi(path, name) if kind == "kalshi" else goog_sample(Path(path))
        histories = {mode: History() for mode in ("imbalance", "imbalance_state")}
        for tape in tapes:
            tape.fills = lru_cache(maxsize=None)(tape.fills)
            @lru_cache(maxsize=200000)
            def memo(side, ent, out, fee):
                return original(tape, side, ent, out, fee)
            engine.accounting = lambda t, s, en, ex, fee: memo(s, tuple(en), tuple(ex), fee)
            try:
                arrays = exit_arrays(tape, Config(q=q), fees)
                for mode, history in histories.items():
                    if history.halted:
                        raise RuntimeError("Cannot silently omit segment after unresolved position")
                    cfg = Config(q=q, mode=mode, allow_proxy_clock=True,
                                 diagnostic_after_50=False, action_policy="ternary_argmax")
                    r = replay(tape, cfg, fees, history=history)
                    diagnose(tape, cfg, fees, r, arrays)
                    r.update(config=asdict(cfg), fees=asdict(fees), source=path,
                             metadata=tape.metadata,
                             engine_sha256=hashlib.sha256(Path("audited_fp.py").read_bytes()).hexdigest())
                    r["oracle"] = oracle(tape, cfg, fees, r["predictions"])
                    s = r["summary"]
                    ready = [p for p in r["predictions"] if p["history_n"] >= cfg.warmup]
                    closed = [t for t in r["trades"] if t["status"] == "closed"]
                    wins = [t["net"] for t in closed if t["net"] > 0]
                    losses = [t["net"] for t in closed if t["net"] < 0]
                    s.pop("forecast_ties", None)  # Under this policy side=0 also means a zero-state win.
                    s.update(ready_forecasts=len(ready),
                             max_history_n=max((p["history_n"] for p in r["predictions"]), default=0),
                             zero_vetoes=sum(p["pzero"] >= max(p["pminus"], p["pplus"]) for p in ready),
                             directional_ties=sum(p["pminus"] == p["pplus"] > p["pzero"] for p in ready),
                             directional_signals=sum(p["side"] != 0 for p in ready),
                             worst_trade=min((t["net"] for t in closed), default=None),
                             best_trade=max((t["net"] for t in closed), default=None),
                             mean_win=float(np.mean(wins)) if wins else None,
                             mean_loss=float(np.mean(losses)) if losses else None,
                             profit_factor=sum(wins)/-sum(losses) if losses else None,
                             oracle_net=r["oracle"]["net"])
                    baseline = json.loads(Path(f"quick_fp_diagnosis/{name}_{tape.segment}_{mode}.json").read_text())
                    r["previous_direction_only_summary"] = baseline["summary"]
                    # Action policy must not change probability history or retrospective labels.
                    assert len(r["predictions"]) == len(baseline["predictions"])
                    for p, old in zip(r["predictions"], baseline["predictions"]):
                        for key in ("anchor_i", "pminus", "pzero", "pplus", "history_n", "y"):
                            assert p[key] == old[key], (name, mode, key)
                    for t in r["trades"]:
                        chosen = t["pplus"] if t["side"] == 1 else t["pminus"]
                        other = t["pminus"] if t["side"] == 1 else t["pplus"]
                        assert chosen > max(t["pzero"], other)
                    for t in closed:
                        assert np.isclose(t["gross"] - t["fees"], t["net"])
                    assert np.isclose(sum(t["net"] for t in closed), s["net_closed"])
                    r["checks"] = dict(unique_direction_winner=True, ledger_reconciled=True,
                                       probabilities_and_labels_unchanged=True)
                    (OUT / f"{name}_{tape.segment}_{mode}.json").write_text(json.dumps(r, indent=2, allow_nan=False, default=json_default)+"\n")
                    summaries.append(s)
                    print(json.dumps(s, default=json_default), flush=True)
            finally:
                engine.accounting = original
    (OUT / "summary.json").write_text(json.dumps(summaries, indent=2, allow_nan=False, default=json_default)+"\n")


if __name__ == "__main__":
    main()
