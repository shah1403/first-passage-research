"""Chronological GOOG replay to diagnose initialization at 100 and 1 shares."""
from collections import Counter
from dataclasses import asdict
import json
import os
from pathlib import Path

import numpy as np
from audited_fp import Config, Fees, History, replay
from audited_fp_runner import load_goog


def json_default(value):
    if isinstance(value, np.generic):
        return value.item()
    raise TypeError(type(value).__name__)


def run(q, mode):
    cfg = Config(q=q, mode=mode, allow_proxy_clock=True,
                 diagnostic_after_50=False, action_policy="ternary_argmax")
    fees = Fees("per_share", per_share=.0035)
    history = History()
    days, total_net, total_trades = [], 0.0, 0
    paths = sorted(Path("upload").glob("goog_*.npz"))
    limit = int(os.environ.get("GOOG_DAY_LIMIT", "0"))
    if limit:
        paths = paths[:limit]
    for path in paths:
        tape = load_goog(path)[0]
        result = replay(tape, cfg, fees, history=history)
        statuses = Counter(p["label_status"] for p in result["predictions"])
        ready = [p for p in result["predictions"] if p["history_n"] >= cfg.warmup]
        row = dict(day=path.stem, rows=len(tape.ts), anchors=len(result["predictions"]),
                   statuses=dict(statuses), history_after_decisions=max(
                       (p["history_n"] for p in result["predictions"]), default=history.total),
                   ready_forecasts=len(ready), zero_vetoes=sum(
                       p["pzero"] >= max(p["pminus"], p["pplus"]) for p in ready),
                   **result["summary"])
        days.append(row)
        total_net += result["summary"]["net_closed"]
        total_trades += result["summary"]["closed_trades"]
        print(q, mode, path.stem, row["anchors"], row["history_after_decisions"],
              row["ready_forecasts"], row["closed_trades"], flush=True)
        if history.halted:
            break
    return dict(config=asdict(cfg), fee=asdict(fees), days=days,
                totals=dict(days=len(days), anchors=sum(d["anchors"] for d in days),
                            usable_labels=sum(sum(d["statuses"].get(x, 0) for x in ("hit", "timeout")) for d in days),
                            insufficient_entry_depth=sum(d["statuses"].get("insufficient_entry_depth", 0) for d in days),
                            entry_unavailable=sum(d["statuses"].get("entry_unavailable", 0) for d in days),
                            ready_forecasts=sum(d["ready_forecasts"] for d in days),
                            zero_vetoes=sum(d["zero_vetoes"] for d in days),
                            closed_trades=total_trades, net_closed=total_net,
                            final_history=history.total, halted=history.halted))


def main():
    out = Path("goog_full_initialization")
    out.mkdir(exist_ok=True)
    results = []
    # Both requested strategy variants at the intended 100-share size.
    for mode in ("imbalance", "imbalance_state"):
        result = run(100, mode)
        results.append(result)
        (out / f"q100_{mode}.json").write_text(json.dumps(result, indent=2, default=json_default) + "\n")
    # Size-isolation diagnostic: same general signal at one displayed share.
    result = run(1, "imbalance_state")
    results.append(result)
    (out / "q1_imbalance_state.json").write_text(json.dumps(result, indent=2, default=json_default) + "\n")
    (out / "summary.json").write_text(json.dumps([r["totals"] | {
        "q": r["config"]["q"], "mode": r["config"]["mode"]} for r in results], indent=2,
        default=json_default) + "\n")


if __name__ == "__main__":
    main()
