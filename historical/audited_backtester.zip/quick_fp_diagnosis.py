"""Fixed quick diagnostic on available data; all clocks explicitly approximate."""
from dataclasses import asdict
from functools import lru_cache
import hashlib
import json
from pathlib import Path
import time

import numpy as np

import audited_fp as engine
from audited_fp import Config, Fees, History, Tape, execute, fill_fee, fill_value, replay
from audited_fp_runner import l1, load_kalshi, load_nse

OUT = Path("quick_fp_diagnosis")


def goog_sample(path):
    with np.load(path) as z:
        n = min(50_000, len(z["ts"]))
        return [Tape(z["ts"][:n].astype(np.int64) * 1_000_000,
                     l1(z["bb"][:n], z["bq"][:n]), l1(z["ba"][:n], z["aq"][:n]),
                     np.arange(n), "GOOG", path.stem + "_first50000", "book_updates",
                     metadata={"source": str(path), "sample": "first 50000 raw observations, no subsampling"})]


def exit_arrays(tape, cfg, fees):
    result = {}
    for side in (-1, 1):
        prices, costs = np.full(len(tape.ts), np.nan), np.full(len(tape.ts), np.nan)
        for i in range(len(tape.ts)):
            fills = tape.fills(i, side, False, cfg.q)
            if fills is not None:
                prices[i] = fill_value(fills)
                costs[i] = fill_fee(fills, fees, not (tape.binary or side == 1))
        result[side] = (prices, costs)
    return result


def vector_late(tape, cfg, fees, tr, arrays):
    side, ei, ai = tr["side"], tr["entry_i"], tr["anchor_i"]
    deadline = tape.deadline(ai, 50)
    result = dict(late_hit_i=None, late_correct_first_passage=False, opposite_move_first=False)
    if deadline is None:
        return dict(result, diagnostic_censored=True)
    first = {}
    for s in (-1, 1):
        ent = tape.fills(ei, s, True, cfg.q)
        if ent is None:
            first[s] = None
            continue
        prices, costs = arrays[s]
        ef = fill_fee(ent, fees, tape.binary or s == 1)
        direction = 1 if tape.binary else s
        net = cfg.q * direction * (prices[ei + 1:] - fill_value(ent)) - ef - costs[ei + 1:]
        ix = np.flatnonzero(net > engine.EPS)
        first[s] = ei + 1 + int(ix[0]) if len(ix) else None
    hit, other = first[side], first[-side]
    if hit is None:
        return dict(result, diagnostic_censored=True)
    opposite = other is not None and other < hit
    result["opposite_move_first"] = opposite
    if hit > deadline:
        result.update(late_hit_i=hit, late_wait_count=int(tape.trade_count[hit] - tape.trade_count[ai]),
                      late_wait_ms=float((tape.ts[hit] - tape.ts[ai]) / 1e6),
                      late_correct_first_passage=bool(not opposite and tape.valid[ei:hit + 1].all()
                                                     and tape.fills(ei, -side, True, cfg.q) is not None))
    return result


def diagnose(tape, cfg, fees, result, arrays):
    ps = [p for p in result["predictions"] if p["history_n"] >= cfg.warmup]
    pmap = {p["anchor_i"]: p for p in result["predictions"]}
    trades = result["trades"]
    closed = [t for t in trades if t["status"] == "closed"]
    matured = [p for p in ps if p["y"] is not None]
    signed = [p for p in matured if p["y"] != 0 and p["side"] != 0]
    zero = [p for p in matured if p["y"] == 0]
    selected_labels = [pmap[t["anchor_i"]] for t in closed]
    moves = [p for p in selected_labels if p["y"] in (-1, 1)]
    # For trades the actual side is retained even if pmap later grows fields.
    for tr in closed:
        tr.update(vector_late(tape, cfg, fees, tr, arrays))
        tr["first_passage_y"] = pmap[tr["anchor_i"]]["y"]
        tr["entry_delay_ms"] = float((tape.ts[tr["entry_i"]] - tape.ts[tr["anchor_i"]]) / 1e6)
        tr["exit_delay_ms"] = float((tape.ts[tr["exit_i"]] - tape.ts[tr["exit_signal_i"]]) / 1e6)
    summary = result["summary"]
    summary.update(
        prediction_count=len(ps), valid_labels=len(matured),
        zero_labels=len(zero), up_labels=sum(p["y"] == 1 for p in matured),
        down_labels=sum(p["y"] == -1 for p in matured),
        direction_correct=sum(p["side"] == p["y"] for p in signed), direction_denominator=len(signed),
        traded_direction_correct=sum(p["side"] == p["y"] for p in moves), traded_move_count=len(moves),
        profitable_trades=sum(t["net"] > engine.EPS for t in closed),
        mean_pzero=float(np.mean([p["pzero"] for p in matured])) if matured else None,
        median_cell_n=float(np.median([p["cell_n"] for p in ps])) if ps else None,
        forecast_ties=sum(p["side"] == 0 for p in ps),
        target_exits=sum(t.get("exit_reason") == "profit_opportunity" for t in closed),
        latency_loss_count=sum(t.get("exit_reason") == "profit_opportunity" and t["net"] <= 0 for t in closed),
        timeout_exits=sum(t.get("exit_reason") == "50_trade_timeout" for t in closed),
        target_net=sum(t["net"] for t in closed if t.get("exit_reason") == "profit_opportunity"),
        timeout_net=sum(t["net"] for t in closed if t.get("exit_reason") == "50_trade_timeout"),
        late_same_side_opportunities=sum(t.get("late_hit_i") is not None for t in closed),
        late_correct_first_passages=sum(t.get("late_correct_first_passage", False) for t in closed),
        late_recoveries_after_opposite=sum(t.get("late_hit_i") is not None and t.get("opposite_move_first", False) for t in closed),
        median_entry_delay_ms=float(np.median([t["entry_delay_ms"] for t in closed])) if closed else None,
        median_wait_ms=float(np.median([t["wait_ms"] for t in closed])) if closed else None,
        rows=len(tape.ts), invalid_rows=int((~tape.valid).sum()),
    )
    by_state = {}
    for p in matured:
        key = str(p["state"])
        d = by_state.setdefault(key, dict(n=0, moves=0, correct=0))
        d["n"] += 1
        if p["y"] != 0 and p["side"] != 0:
            d["moves"] += 1
            d["correct"] += int(p["side"] == p["y"])
    result["by_state"] = by_state


def oracle(tape, cfg, fees, predictions):
    """Hindsight side/skip benchmark; same entry rules, one position at a time."""
    trades, blocked = [], -1
    for p in predictions:
        i = p["anchor_i"]
        if p["history_n"] < cfg.warmup or i <= blocked:
            continue
        if blocked >= 0 and tape.ts[i] <= tape.ts[blocked]:
            continue
        choices = [execute(tape, i, s, cfg, fees)[0] for s in (-1, 1)]
        choices = [c for c in choices if c["status"] == "closed" and c["net"] > engine.EPS]
        if choices:
            best = max(choices, key=lambda t: t["net"])
            trades.append(best)
            blocked = best["exit_i"]
    return dict(trades=len(trades), gross=sum(t["gross"] for t in trades),
                fees=sum(t["fees"] for t in trades), net=sum(t["net"] for t in trades),
                definition="hindsight side/skip, same 50-count exit rule and fees, sequential; not globally optimized")


def main():
    OUT.mkdir(exist_ok=True)
    jobs = [
        ("INFY", "nse", "upload/orderbook_infy_10000snaps.npz", 100, Fees("nse_intraday")),
        ("TATAMOTORS", "nse", "upload/orderbook_tatamotors_10000snaps.npz", 100, Fees("nse_intraday")),
        ("BTC15M", "kalshi", "quant_results/kalshi-btc15m-2026-09-11.txt.zst.features.csv.gz", 1, Fees("kalshi")),
        ("NFL", "kalshi", "sports_v4/NFL/features.csv.gz", 1, Fees("kalshi")),
        ("MLB", "kalshi", "sports_v4/MLB/features.csv.gz", 1, Fees("kalshi")),
        ("GOOG", "goog", "upload/goog_2026-07-01.npz", 100, Fees("per_share", per_share=.0035)),
    ]
    summaries = []
    raw_accounting = engine.accounting
    for name, kind, path, q, fees in jobs:
        started = time.monotonic()
        print("START", name, flush=True)
        tapes = load_nse(path) if kind == "nse" else load_kalshi(path, name) if kind == "kalshi" else goog_sample(Path(path))
        histories = {m: History() for m in ("imbalance", "imbalance_state")}
        for tape in tapes:
            tape.fills = lru_cache(maxsize=None)(tape.fills)
            @lru_cache(maxsize=200000)
            def memo(side, ent, out, fee):
                return raw_accounting(tape, side, ent, out, fee)
            engine.accounting = lambda t, s, ent, out, fee: memo(s, tuple(ent), tuple(out), fee)
            cfg = Config(q=q, allow_proxy_clock=True, diagnostic_after_50=False,
                         action_policy="direction_argmax")
            arrays = exit_arrays(tape, cfg, fees)
            first_predictions = None
            for mode, history in histories.items():
                if history.halted:
                    print("HALTED", name, mode, "prior unresolved position", flush=True)
                    continue
                cfg = Config(q=q, mode=mode, allow_proxy_clock=True, diagnostic_after_50=False,
                             action_policy="direction_argmax")
                r = replay(tape, cfg, fees, history=history)
                diagnose(tape, cfg, fees, r, arrays)
                r["config"], r["fees"] = asdict(cfg), asdict(fees)
                r["source"], r["metadata"] = path, tape.metadata
                r["engine_sha256"] = hashlib.sha256(Path("audited_fp.py").read_bytes()).hexdigest()
                if first_predictions is None:
                    first_predictions = r["predictions"]
                    ceiling = oracle(tape, cfg, fees, first_predictions)
                r["oracle"] = ceiling
                r["summary"]["oracle_net"] = ceiling["net"]
                (OUT / f"{name}_{tape.segment}_{mode}.json").write_text(json.dumps(r, indent=2, allow_nan=False) + "\n")
                summaries.append(r["summary"])
                print(json.dumps(r["summary"]), flush=True)
            engine.accounting = raw_accounting
        print("DONE", name, round(time.monotonic() - started, 2), "seconds", flush=True)
        (OUT / "summary.json").write_text(json.dumps(summaries, indent=2, allow_nan=False) + "\n")


if __name__ == "__main__":
    main()
