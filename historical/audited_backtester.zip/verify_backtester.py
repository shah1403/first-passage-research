"""Run tester verification and inventory available inputs, never strategy PnL."""

import hashlib
import io
import json
from pathlib import Path
import time
import unittest

import numpy as np
import pandas as pd


ROOT = Path(__file__).resolve().parent
OUT = ROOT / "backtester_audit"


def inventory():
    rows = []
    for p in sorted((ROOT / "upload").glob("*.npz")):
        with np.load(p) as z:
            fields = z.files
            goog = "bb" in fields
            rows.append(dict(path=str(p.relative_to(ROOT)), asset="GOOG" if goog else str(z["symbol"]),
                             rows=len(z["ts"]), fields=fields,
                             monotone_timestamps=bool(np.all(np.diff(z["ts"]) >= 0)),
                             clock="book_updates" if goog else "snapshot_linked_trades",
                             approved_for_exact_50_trade_test=False))
    for base in ["quant_results", "sports_v3", "sports_v4"]:
        for p in sorted((ROOT / base).rglob("*.csv.gz")):
            if "features" not in p.name:
                continue
            d = pd.read_csv(p, usecols=["t", "segment"])
            rows.append(dict(path=str(p.relative_to(ROOT)), rows=len(d),
                             segments=int(d.segment.nunique()),
                             monotone_timestamps=bool(np.all(np.diff(d.t) >= 0)),
                             clock="retained_trade_messages", approved_for_exact_50_trade_test=False,
                             warning="Overlapping versions are not independent markets; original parser excludes invalid-book trades"))
    try:
        import pyarrow.parquet as pq
        for name in ["orderbook.parquet", "trades.parquet"]:
            p = ROOT / name
            if p.exists():
                pf = pq.ParquetFile(p)
                tickers = pd.read_parquet(p, columns=["ticker"]).ticker.value_counts().to_dict()
                rows.append(dict(path=name, rows=pf.metadata.num_rows, columns=pf.schema_arrow.names,
                                 tickers=tickers, approved_for_exact_50_trade_test=False,
                                 warning="Paired book/trade alignment and sequence semantics not yet validated"))
    except ImportError:
        rows.append(dict(path="*.parquet", warning="Parquet reader unavailable"))
    for p in sorted((ROOT / "stock_lob").rglob("*.txt")):
        rows.append(dict(path=str(p.relative_to(ROOT)), approved_for_exact_50_trade_test=False,
                         warning="FI-2010 transformed data: native prices, identities and timestamps not established for executable PnL"))
    for p in sorted(ROOT.glob("*.zst")):
        rows.append(dict(path=str(p.relative_to(ROOT)), approved_for_exact_50_trade_test=False,
                         warning="Raw stream available; full-event parser, fee metadata and gap validation remain required"))
    return rows


def main():
    started = time.monotonic()
    stream = io.StringIO()
    suite = unittest.defaultTestLoader.discover(str(ROOT / "tests"))
    result = unittest.TextTestRunner(stream=stream, verbosity=2).run(suite)
    sources = ["audited_fp.py", "audited_fp_runner.py", "tests/test_audited_fp.py"]
    report = dict(tests=result.testsRun, failures=len(result.failures), errors=len(result.errors),
                  skipped=len(result.skipped), passed=result.wasSuccessful(),
                  elapsed_seconds=time.monotonic() - started,
                  asset_profitability_tests_run=False,
                  source_sha256={name: hashlib.sha256((ROOT / name).read_bytes()).hexdigest() for name in sources},
                  inventory=inventory())
    OUT.mkdir(exist_ok=True)
    (OUT / "verification.json").write_text(json.dumps(report, indent=2) + "\n")
    (OUT / "test_log.txt").write_text(stream.getvalue())
    print(json.dumps({k: v for k, v in report.items() if k != "inventory"}, indent=2))
    print(f"Inventoried {len(report['inventory'])} data files; no asset PnL experiment run.")
    if not result.wasSuccessful():
        raise SystemExit(1)


if __name__ == "__main__":
    main()
